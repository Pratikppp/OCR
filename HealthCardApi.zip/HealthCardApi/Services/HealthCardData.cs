public class HealthCardData
{
    public string Name { get; set; }
    public string Address { get; set; }
    public string HealthCardNumber { get; set; }
    public string Phone { get; set; }
    public string ValidFrom { get; set; }
    public string ExtraInfo { get; set; } // any additional info
}
